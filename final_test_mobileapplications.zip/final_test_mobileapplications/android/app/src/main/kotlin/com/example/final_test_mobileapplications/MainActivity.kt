package com.example.final_test_mobileapplications

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
